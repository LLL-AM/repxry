FILES_PATH=${FILES_PATH:-./}

green(){ echo -e "\033[32m\033[01m$1\033[0m";}
yellow(){ echo -e "\033[33m\033[01m$1\033[0m";}
blue(){ echo -e "\033[36m\033[01m$1\033[0m";}

CURRENT_VERSION=''

RELEASE_LATEST=''

get_current_version() {
    if [[ -f "${FILES_PATH}/web" ]]; then
        CURRENT_VERSION="$(${FILES_PATH}/web -version | awk 'NR==1 {print $2}')"
        CURRENT_VERSION="v${CURRENT_VERSION#v}"
    else
        CURRENT_VERSION=""
    fi
}

get_latest_version() {
    RELEASE_LATEST="$(curl -IkLs -o ${TMP_DIRECTORY}/NUL -w %{url_effective} https://github.com/LLL-AM/repxry/releases/latest | grep -o "[^/]*$")"
    RELEASE_LATEST="v${RELEASE_LATEST#v}"
    if [[ -z "$RELEASE_LATEST" ]]; then
        echo "error: Failed to get the latest release version, please check your network."
        exit 1
    fi
}

download_repxry() {
    DOWNLOAD_LINK="https://github.com/LLL-AM/repxry/releases/download/$RELEASE_LATEST/repxry-linux-64.zip"
    if ! wget -qO "$ZIP_FILE" "$DOWNLOAD_LINK"; then
        echo 'error: Download failed! Please check your network or try again.'
        return 1
    fi
    return 0
    if ! wget -qO "$ZIP_FILE.dgst" "$DOWNLOAD_LINK.dgst"; then
        echo 'error: Download failed! Please check your network or try again.'
        return 1
    fi
    if [[ "$(cat "$ZIP_FILE".dgst)" == 'Not Found' ]]; then
        echo 'error: This version does not support verification. Please replace with another version.'
        return 1
    fi

    for LISTSUM in 'md5' 'sha1' 'sha256' 'sha512'; do
        SUM="$(${LISTSUM}sum "$ZIP_FILE" | sed 's/ .*//')"
        CHECKSUM="$(grep ${LISTSUM^^} "$ZIP_FILE".dgst | grep "$SUM" -o -a | uniq)"
        if [[ "$SUM" != "$CHECKSUM" ]]; then
            echo 'error: Check failed! Please check your network or try again.'
            return 1
        fi
    done
}

decompression() {
    busybox unzip -q "$1" -d "$TMP_DIRECTORY"
    EXIT_CODE=$?
    if [ ${EXIT_CODE} -ne 0 ]; then
        "rm" -r "$TMP_DIRECTORY"
        echo "removed: $TMP_DIRECTORY"
        exit 1
    fi
}

install_repxry() {
    install -m 755 ${TMP_DIRECTORY}/xray ${FILES_PATH}/web
}

run_repxry() {
   re_uuid=$(curl -s $REPLIT_DB_URL/re_uuid)   
    if [ "${re_uuid}" = "" ]; then
        NEW_uuid="$(cat /proc/sys/kernel/random/uuid)"
        curl -sXPOST $REPLIT_DB_URL/re_uuid="${NEW_uuid}" 
    fi
    if [ "${uuid}" = "" ]; then
        user_uuid=$(curl -s $REPLIT_DB_URL/re_uuid)
    else
        user_uuid=${uuid}
    fi
    cp -f ./config.json /tmp/config.json
    sed -i "s|uuid|${user_uuid}|g" /tmp/config.json
    ./web -c /tmp/config.json 2>&1 >/dev/null &
    echo
    green "当前已安装的repxry正式版本：$RELEASE_LATEST"
    echo
    UA_Browser="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36"
    v4=$(curl -s4m6 ip.sb -k)
    v4l=`curl -sm6 --user-agent "${UA_Browser}" http://ip-api.com/json/$v4?lang=zh-CN -k | cut -f2 -d"," | cut -f4 -d '"'`
    echo
    green "当前检测到的IP：$v4    地区：$v4l"
    echo
    blue "相关信息如下------------------------------"
echo
    yellow "vm-配置明文如下，相关参数可复制到客户端"
    echo "服务器地址：${REPL_SLUG}.${REPL_OWNER}.repl.co"
    echo "端口：443"
    echo "uuid：$user_uuid"
    echo "传输协议：ws"
    echo "host/sni：${REPL_SLUG}.${REPL_OWNER}.repl.co"
    echo "path路径：/$user_uuid-vm"
    echo "tls：开启"
echo
blue "-------------------------------------------"
echo
yellow "vl-配置明文如下，相关参数可复制到客户端"
    echo "服务器地址：${REPL_SLUG}.${REPL_OWNER}.repl.co"
    echo "端口：443"
    echo "uuid：$user_uuid"
    echo "传输协议：ws"
    echo "host/sni：${REPL_SLUG}.${REPL_OWNER}.repl.co"
    echo "path路径：/$user_uuid-vl"
    echo "tls：开启"   
echo
blue "-------------------------------------------"
echo
yellow "tr-配置明文如下，相关参数可复制到客户端"
    echo "服务器地址：${REPL_SLUG}.${REPL_OWNER}.repl.co"
    echo "端口：443"
    echo "密码：$user_uuid"
    echo "传输协议：ws"
    echo "host/sni：${REPL_SLUG}.${REPL_OWNER}.repl.co"
    echo "path路径：/$user_uuid-tr"
    echo "tls：开启"
    
echo
blue "-------------------------------------------"

    echo
green "安装完毕===================================="

echo
while true; do
curl https://${REPL_SLUG}.${REPL_OWNER}.repl.co;sleep 600
done
tail -f
}

TMP_DIRECTORY="$(mktemp -d)"
ZIP_FILE="${TMP_DIRECTORY}/web.zip"

get_current_version
get_latest_version
if [ "${RELEASE_LATEST}" = "${CURRENT_VERSION}" ]; then
    "rm" -rf "$TMP_DIRECTORY"
    run_repxry
fi
download_repxry
EXIT_CODE=$?
if [ ${EXIT_CODE} -eq 0 ]; then
    :
else
    "rm" -r "$TMP_DIRECTORY"
    echo "removed: $TMP_DIRECTORY"
    run_repxry
fi
decompression "$ZIP_FILE"
install_repxry
"rm" -rf "$TMP_DIRECTORY"
run_repxry